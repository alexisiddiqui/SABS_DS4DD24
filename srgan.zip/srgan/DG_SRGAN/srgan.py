"""
Code for running only the DNN version of the ic50 prediction application.
"""
import random
import torch
from torch import Tensor
from collections import defaultdict
import numpy as np
from torch.utils.data import DataLoader
from srgan.DNN_only.data import LabelledDataset, DG_Labelled_Dataset, UnlabelledDataset
from srgan.DG_SRGAN.models import R_DNN, ECFP_MLP_Generator
from srgan.settings import Settings
from srgan.srgan import Experiment
from srgan.utility import gpu
from sklearn.metrics.pairwise import cosine_similarity



class SRGAN_IC50(Experiment):
    """Runs the experiment for a DNN only version of the ic50 application."""

    def load_raw_data(self):
        settings = self.settings
        self.train_dataset = LabelledDataset(csv_path=settings.train_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
        self.validation_dataset = LabelledDataset(csv_path=settings.validation_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        

        self.test_dataset = LabelledDataset(csv_path=settings.test_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
        self.unlabeled_dataset = UnlabelledDataset(sdf_path=settings.unlabeled_dataset_path,
                                            seed=settings.labeled_dataset_seed)

    def dataset_setup(self):
        settings = self.settings

        self.load_raw_data()

        self.train_dataset_loader = DataLoader(self.train_dataset, batch_size=settings.batch_size,
                                               pin_memory=self.settings.pin_memory,
                                               num_workers=settings.number_of_data_workers)
        self.validation_dataset_loader = DataLoader(self.validation_dataset, batch_size=settings.batch_size,
                                                    pin_memory=self.settings.pin_memory,
                                                    num_workers=settings.number_of_data_workers)
        
        self.test_dataset_loader = DataLoader(self.test_dataset, batch_size=None,
                                                pin_memory=self.settings.pin_memory,
                                                num_workers=settings.number_of_data_workers)
        
        self.unlabeled_dataset_loader = DataLoader(self.unlabeled_dataset, batch_size=settings.batch_size,
                                                pin_memory=self.settings.pin_memory,
                                                num_workers=settings.number_of_data_workers)
        

    def model_setup(self):
        """Prepares all the model architectures required for the application."""
        self.DNN = R_DNN()
        self.D = R_DNN()
        self.G = ECFP_MLP_Generator()



    def labeled_loss_function(self, predicted_labels, labels, order=2):
        """Computes the labelled loss, even though it is single goal it should handle missing labels."""
        threshold = 96
        # Find the indexes of non negative labels
        grad_indexes = np.where(labels >= 0)[0]
        
        predicted_labels = predicted_labels[grad_indexes]
        labels = labels[grad_indexes]

        # clip values above threshold to threshold
        predicted_labels = torch.clamp(predicted_labels, max=threshold)
        labels = torch.clamp(labels, max=threshold)
        
        # compute log
        predicted_labels = torch.log(predicted_labels)
        labels = torch.log(labels)

        return (predicted_labels - labels).abs().pow(order).mean()


    def evaluation_epoch(self, settings, network, dataset, summary_writer, summary_name, shuffle=True):
        
        dataset_loader = DataLoader(dataset, batch_size=settings.batch_size,
                                    pin_memory=self.settings.pin_memory,
                                    num_workers=settings.number_of_data_workers)
        
        predicted_ic50, true_ic50 = np.array([]), np.array([])

        for index, (label, ic50) in enumerate(dataset_loader):
            
            ic50 = ic50.abs()
            # print("ic50: ", ic50.detach().cpu().numpy())
            label, ic50 = label.to(gpu), ic50.to(gpu)
            
            
            prediction = network(label)

            predicted_ic50 = np.append(predicted_ic50, prediction.detach().cpu().numpy())
            true_ic50 = np.append(true_ic50, ic50.detach().cpu().numpy())
            if (index * settings.batch_size) >= 100:
                # print(f"Index: {index}")
                break

        signed_mean_error = np.mean(predicted_ic50 - true_ic50)
        mean_error = np.mean(np.abs(predicted_ic50 - true_ic50))
        mean_squared_error = np.mean(np.square(predicted_ic50 - true_ic50))




        summary_writer.add_scalar(summary_name + '/Signed Mean Error', signed_mean_error)
        summary_writer.add_scalar(summary_name + '/Mean Error', mean_error)
        summary_writer.add_scalar(summary_name + '/Mean Squared Error', mean_squared_error)

        return mean_error



    def validation_summaries(self, step):
        """Prepares the summaries that should be run for the given application."""
        settings = self.settings
        dnn_summary_writer = self.dnn_summary_writer
        gan_summary_writer = self.gan_summary_writer
        DNN = self.DNN
        D = self.D
        G = self.G
        train_dataset = self.train_dataset
        validation_dataset = self.validation_dataset
        test_dataset = self.test_dataset
        unlabeled_dataset = self.unlabeled_dataset
 
        print("DNN validation summaries")

        # DNN only
        dnn_train_error = self.evaluation_epoch(settings, DNN, train_dataset, dnn_summary_writer, '2 Train Error')
        dnn_validation_error = self.evaluation_epoch(settings, DNN, validation_dataset, dnn_summary_writer, '1 Validation Error')

        # GAN
        print("GAN validation summaries")
        gan_train_error = self.evaluation_epoch(settings, D, train_dataset, gan_summary_writer, '2 Train Error')
        gan_validation_error = self.evaluation_epoch(settings, D, validation_dataset, gan_summary_writer, '1 Validation Error')

        z = torch.tensor(np.random.normal(size=[settings.batch_size, G.input_size]).astype(np.float32)).to(gpu)

        fake_examples = G(z)

        # fake_examples_array = fake_examples.to('cpu').detach().numpy()
        fake_predicted_labels = D(fake_examples)
        if torch.isnan(fake_predicted_labels).any():
            print('NaNs detected in fake_predicted_labels_array')
            print(fake_predicted_labels)
        fake_predicted_labels_array = fake_predicted_labels.to('cpu').detach().numpy()
        real_labels_array = validation_dataset.values[:settings.validation_dataset_size].abs()
        real_examples_array = validation_dataset.examples[:settings.validation_dataset_size]

        # plot real and fake histograms to summary writer
        gan_summary_writer.add_histogram('Real Labels', real_labels_array.flatten(), step)
        gan_summary_writer.add_histogram('Fake Labels', fake_predicted_labels_array.flatten(), step)

        dnn_fake_predicted_labels = DNN(fake_examples)
        if torch.isnan(dnn_fake_predicted_labels).any():
            print('NaNs detected in dnn_fake_predicted_labels_array')
            print(dnn_fake_predicted_labels)
        dnn_fake_predicted_labels_array = dnn_fake_predicted_labels.to('cpu').detach().numpy()

        dnn_summary_writer.add_histogram('Fake Labels', dnn_fake_predicted_labels_array.flatten(), step)


        fake_examples_array = fake_examples.to('cpu').detach().numpy()
        real_examples_array = real_examples_array.to('cpu').detach().numpy()
        # find mean cosine between real and fake examples
        cosine_similarity_matrix = cosine_similarity(fake_examples_array, real_examples_array)
        mean_cosine_similarity = np.mean(cosine_similarity_matrix)
        
        gan_summary_writer.add_scalar('Fake and Val Cosine Similarity', mean_cosine_similarity, step)

        unlabelled_examples_array = unlabeled_dataset.examples[:settings.validation_dataset_size]
        unlabelled_examples = unlabelled_examples_array.to(gpu)
        unlabelled_predictions = D(unlabelled_examples)
        if torch.isnan(unlabelled_predictions).any():
            print('NaNs detected in unlabelled_predictions_array')
            print(unlabelled_predictions)

        unlabelled_predictions_array = unlabelled_predictions.to('cpu').detach().numpy()

        unl_cosine_similarity_matrix = cosine_similarity(fake_examples_array, unlabelled_examples_array)
        unl_mean_cosine_similarity = np.mean(unl_cosine_similarity_matrix)

        # histogram of unlabelled predictions
        gan_summary_writer.add_histogram('Unlabelled Predictions', unlabelled_predictions_array.flatten(), step)

        dnn_unlabelled_predictions = DNN(unlabelled_examples)
        dnn_unlabelled_predictions_array = dnn_unlabelled_predictions.to('cpu').detach().numpy()

        dnn_summary_writer.add_histogram('Unlabelled Predictions', dnn_unlabelled_predictions_array.flatten(), step)

        gan_summary_writer.add_scalar('Fake and Unlabelled Cosine Similarity', unl_mean_cosine_similarity, step)

        train_examples = train_dataset.examples[:settings.validation_dataset_size]
        train_examples_array = train_examples.to(gpu)
        train_predictions = D(train_examples_array)
        train_predictions_array = train_predictions.to('cpu').detach().numpy()

        gan_summary_writer.add_histogram('Train Predictions', train_predictions_array.flatten(), step)

        dnn_train_predictions = DNN(train_examples_array)
        dnn_train_predictions_array = dnn_train_predictions.to('cpu').detach().numpy()

        dnn_summary_writer.add_histogram('Train Predictions', dnn_train_predictions_array.flatten(), step)


        self.test_summaries()

    def test_summaries(self):
        # settings = self.settings
        test_dataset = self.test_dataset
        network = self.D
        summary_writer = self.gan_summary_writer
        summary_name = "0 Test Error"

        self.test(network, test_dataset, summary_writer, summary_name)

        network = self.DNN
        summary_writer = self.dnn_summary_writer

        self.test(network, test_dataset, summary_writer, summary_name)



    def test(self, network, test_dataset, summary_writer, summary_name, shuffle=True):
        print("test summaries")
        totals = defaultdict(lambda: 0)

        for index, (label, ic50) in enumerate(test_dataset):
            print(index, end='\r')
            ic50 = ic50.abs()
            label, ic50 = label.to(gpu), ic50.to(gpu)
            predicted_ic50 = network(label)
            totals['Signed Mean Error'] += (predicted_ic50 - ic50).mean()
            totals['Mean Error'] += (predicted_ic50 - ic50).abs().mean()
            totals['Mean Squared Error'] += (predicted_ic50 - ic50).square().mean()
            if index >= 10:
                break

        summary_writer.add_scalar(f"{summary_name}/Signed Mean Error", totals['Signed Mean Error']/10)
        summary_writer.add_scalar(f"{summary_name}/Mean Error", totals['Mean Error']/10)
        summary_writer.add_scalar(f"{summary_name}/Mean Squared Error", totals['Mean Squared Error']/10)

        pass


    def gradient_penalty_calculation(self, fake_examples: Tensor, unlabeled_examples: Tensor) -> Tensor:
        """Calculates the gradient penalty from the given fake and real examples."""
        alpha_shape = [1] * len(unlabeled_examples.size())
        alpha_shape[0] = self.settings.batch_size
        alpha = torch.rand(alpha_shape, device=gpu)
        # print("Gradient Penalty Calculation")
        
        interpolates = (alpha * unlabeled_examples.detach().requires_grad_() +
                        (1 - alpha) * fake_examples.detach().requires_grad_())

        if self.settings.interpolation_binary_approximation:
            interpolates = self.binary_approximation(interpolates)

        interpolates_loss = self.interpolate_loss_calculation(interpolates)
        gradients = torch.autograd.grad(outputs=interpolates_loss, inputs=interpolates,
                                        grad_outputs=torch.ones_like(interpolates_loss, device=gpu),
                                        create_graph=True)[0]
        gradient_norm = gradients.view(unlabeled_examples.size(0), -1).norm(dim=1)
        self.gradient_norm = gradient_norm
        norm_excesses = torch.max(gradient_norm - 1, torch.zeros_like(gradient_norm))
        gradient_penalty = (norm_excesses ** 2).mean() * self.settings.gradient_penalty_multiplier
        return gradient_penalty

    # def binary_approximation(self, tensor, threshold=0.5):
    #     # Apply Sigmoid to bring values to the range [0, 1]
    #     sigmoid_tensor = torch.sigmoid(tensor)
        
    #     # Scale the values to push them closer to 0 or 1
    #     scaled_tensor = sigmoid_tensor * (1 / threshold)
        
    #     # Clip the values to make sure they stay within [0, 1]
    #     clipped_tensor = torch.clamp(scaled_tensor, 0, 1)
    #     return clipped_tensor

    def binary_approximation(self, tensor, threshold=0.5):
        sigmoid_tensor = torch.sigmoid(tensor)
        return (sigmoid_tensor > threshold).float()

    def evaluate(self):
        return super().evaluate()

        pass



class DG_SRGAN_IC50(SRGAN_IC50):

    def load_raw_data(self):
        settings = self.settings
        self.train_dataset = DG_Labelled_Dataset(csv_path=settings.train_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
        self.validation_dataset = DG_Labelled_Dataset(csv_path=settings.validation_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        

        self.test_dataset = DG_Labelled_Dataset(csv_path=settings.test_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
        self.unlabeled_dataset = UnlabelledDataset(sdf_path=settings.unlabeled_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
    def labeled_loss_function(self, predicted_labels, labels, order=2):
        """Computes the labelled loss, but because it is dual goal it must handle missing labels."""
        threshold = 96

        # find length of axis 1 for labels
        no_labels = labels.size()[1]
        loss = 0

        for idx in range(no_labels):
            labs = labels[:, idx]
            preds = predicted_labels[:, idx]

         # Find the indexes of non-nan and non-negative labels
            grad_indexes = np.where((~np.isnan(labs)) & (labs >= 0))[0]

            labs = labs[grad_indexes].abs()
            preds = preds[grad_indexes]

            # clip values above threshold to threshold
            preds = torch.clamp(preds, max=threshold)
            labs = torch.clamp(labs, max=threshold)

            # # # compute log
            # labs = torch.log(labs) 
            # preds = torch.log(preds.abs())

            loss += (preds - labs).pow(order).mean()

        loss *= self.settings.labeled_loss_multiplier
        
        return loss/no_labels



    def model_setup(self):
        layersizes =[2**10, 2**10, 2**9, 2**7, 2**1]
        self.DNN = R_DNN(layersize=layersizes)
        self.D = R_DNN(layersize=layersizes)
        self.G = ECFP_MLP_Generator()

 