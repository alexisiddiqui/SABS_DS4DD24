"""
MLP Model for DNN only
"""
import torch
from torch import nn
from torch.nn import Module, Linear
import torch.nn.functional as F

from srgan.utility import gpu,seed_all


batch_norm = False


class R_DNN(Module):
    """MLP Based Regressor DNN only (without batch normalization)"""
    def __init__(self, layersize=[2**10, 2**10, 2**9, 2**7, 2**0], dropout=0.33):
        super().__init__()
        self.hidden = nn.ModuleList()
        self.dropout = dropout
        self.features = None
        for idx, layer in enumerate(layersize[:-2]):
            self.hidden.append(nn.Linear(layersize[idx], layersize[idx+1]))
        self.output = nn.Linear(layersize[-2], layersize[-1])  # Output layer for regression

    def forward(self, x):
        for idx, layer in enumerate(self.hidden):
            x = F.relu(layer(x))
            x = F.dropout(x, self.dropout, training=self.training)
            if idx == len(self.hidden) - 1:  # Last hidden layer
                self.features = x  # Capture the features from t
        x = self.output(x)
        return x.squeeze()
    

class ECFP_MLP_Generator(Module):
    """MLP Based Generator for DNN only (without batch normalization)
        Generates ECFPS so output should be binary"""
    def __init__(self, layersize=[2**10, 2**10, 2**10], dropout=0.33):
        super().__init__()
        self.hidden = nn.ModuleList()
        self.dropout = dropout
        # self.features = None
        self.input_size = layersize[0]

        for idx, layer in enumerate(layersize[:-2]):
            self.hidden.append(nn.Linear(layersize[idx], layersize[idx+1]))
        self.output = nn.Linear(layersize[-2], layersize[-1])

    def forward(self, x):
        for idx, layer in enumerate(self.hidden):
            x = F.relu(layer(x))
            x = F.dropout(x, self.dropout, training=self.training)
           
        x = torch.sigmoid(self.output(x))
        x = (x > 0.5).float()
        return x
    