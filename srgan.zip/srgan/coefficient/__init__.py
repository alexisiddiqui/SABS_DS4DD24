"""The coefficient estimation module."""
