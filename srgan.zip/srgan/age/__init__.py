"""The age estimation module."""
