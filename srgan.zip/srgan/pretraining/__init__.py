"""Code for the ImageNet application. Used for pre-training models on an unrelated database."""
