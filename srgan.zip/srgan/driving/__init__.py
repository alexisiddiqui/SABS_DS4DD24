"""A module for the driving steering angle application."""
