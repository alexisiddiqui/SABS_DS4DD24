"""
MLP Model for DNN only
"""
import torch
from torch import nn
from torch.nn import Module, Linear
import torch.nn.functional as F

from srgan.utility import gpu,seed_all


batch_norm = False


class R_DNN(Module):
    """MLP Based Regressor DNN only (without batch normalization)"""
    def __init__(self, layersize=[2**10, 2**10, 2**9, 2**7, 2**0], dropout=0.33):
        super().__init__()
        self.hidden = nn.ModuleList()
        self.dropout = dropout
        self.features = None

        for idx, layer in enumerate(layersize[:-2]):
            self.hidden.append(nn.Linear(layersize[idx], layersize[idx+1]))
        self.output = nn.Linear(layersize[-2], layersize[-1])  # Output layer for binary classification

    def forward(self, x):
        for layer in self.hidden:
            x = F.relu(layer(x))
            x = F.dropout(x, self.dropout, training=self.training)
        x = self.output(x)
        return x.squeeze()