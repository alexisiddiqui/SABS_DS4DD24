"""
Code for the SMILES and IC50 databases.
"""
import os
import torch
import numpy as np
import pandas as pd
import ast

from rdkit import Chem
from rdkit.Chem import AllChem

from torch.utils.data import Dataset


from srgan.utility import gpu, clean_scientific_notation



class LabelledDataset(Dataset):
    """A dataset that takes in a csv_path and extracts the smiles and labels from it."""
    def __init__(self, 
                 csv_path, 
                 smiles_column:str='SMILES', 
                 value_column:str='avg_IC50',
                 seed=None): # need to add code for larger batch sizes
        
        self.csv_path = csv_path
        self.smiles_column = smiles_column
        self.value_column = value_column
        self.seed = seed

        # self.df = pd.read_csv(self.csv_path)
        self.df = pd.read_pickle(self.csv_path)
        # self.df = self.df.dropna()
        #convert strings to all vals
        # self.df = self.df.map(ast.literal_eval)

        # extract data to numpy arrays
        self.smiles = np.array(self.df[self.smiles_column])
        self.length = self.smiles.shape[0]
        print(self.length)
        # labels need to match the number of columns
        self.values = self.prepare_values(np.array(self.df[self.value_column]))

        # convert smiles to ECFP
        self.labels = self.smiles_to_ecfp(self.smiles)


    def __len__(self):
        return self.length
    
    def __getitem__(self, index):
        looped_index = index % self.length # uhhh batch sizes larger than the datastets have no effect 
        return self.labels[looped_index], self.values[looped_index]
        
    def prepare_values(self, values:np.array):
        """Converts values to a tensor"""
        # if any of the values are nan, convert them to -1, any value > 0 is valid
        values = np.nan_to_num(values, nan=-1)
        
        return torch.tensor(values, dtype=torch.float32)
    
    def smiles_to_ecfp(self, smiles:np.array):
        """Converts smiles to ECFP of an array"""
        
        ecfps = []
        for smile in smiles:
            # print(smile)
            mol = Chem.MolFromSmiles(smile)
            # print(mol)
            ecfp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)
            ecfps.append(ecfp)

        ecfps = np.array(ecfps, dtype=int)  # Convert list of arrays to a 2D numpy array
        ecfps = torch.tensor(ecfps, dtype=torch.float32)  # Convert to tensor

        return ecfps
    
    def train_val_split(self, frac=0.9)->(Dataset, Dataset):
        """Splits the dataset into a train and validation set"""
        if self.seed is not None:
            torch.manual_seed(self.seed) 
        train_size = int(self.length * frac)
        val_size = self.length - train_size

        train_dataset, val_dataset = torch.utils.data.random_split(self, [train_size, val_size])

        return train_dataset, val_dataset
    

class DG_Labelled_Dataset(LabelledDataset):
    """A dataset that takes in a csv_path and extracts the smiles and dual labels from it.
        Need to add a function that converts nan values to -1
    """

    def __init__(self, 
                csv_path, 
                smiles_column:str='SMILES', 
                value_column:list=['f_avg_IC50','r_avg_IC50'],
                seed=None): # need to add code for larger batch sizes
        
        self.csv_path = csv_path
        self.smiles_column = smiles_column
        self.value_column = value_column
        self.seed = seed

        # self.df = pd.read_csv(self.csv_path)
        self.df = pd.read_pickle(self.csv_path)
        # self.df = self.df.dropna()
        #convert strings to all vals
        # self.df = self.df.map(ast.literal_eval)

        # extract data to numpy arrays
        self.smiles = np.array(self.df[self.smiles_column])
        self.length = self.smiles.shape[0]
        print(self.length)
        # labels need to match the number of columns
        self.values = self.prepare_values(np.array(self.df[self.value_column]))

        # convert smiles to ECFP
        self.labels = self.smiles_to_ecfp(self.smiles)

    def prepare_values(self, values:np.array):
        """Converts values to a tensor"""
        # if any of the values are nan, convert them to the negative of the other value that is not nan
        mean = np.nanmean(values, axis=1)
        values = np.nan_to_num(values, nan=mean*-1)

        assert values.shape[1] == len(self.value_column), "Number of columns in values does not match number of columns in value_column"

        return torch.tensor(values, dtype=torch.float32)


        