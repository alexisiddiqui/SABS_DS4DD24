"""
Code for running only the DNN version of the ic50 prediction application.
"""
import random
from collections import defaultdict
import numpy as np
from torch.utils.data import DataLoader
from srgan.DNN_only.data import LabelledDataset, DG_Labelled_Dataset
from srgan.DNN_only.models import R_DNN
from srgan.settings import Settings
from srgan.dnn import DnnExperiment
from srgan.utility import gpu


class DNN_IC50(DnnExperiment):
    """Runs the experiment for a DNN only version of the ic50 application."""

    def load_raw_data(self):
        settings = self.settings
        self.train_dataset = LabelledDataset(csv_path=settings.train_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
        self.validation_dataset = LabelledDataset(csv_path=settings.validation_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        

        self.test_dataset = LabelledDataset(csv_path=settings.test_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        

    def dataset_setup(self):
        settings = self.settings

        self.load_raw_data()

        self.train_dataset_loader = DataLoader(self.train_dataset, batch_size=settings.batch_size,
                                               pin_memory=self.settings.pin_memory,
                                               num_workers=settings.number_of_data_workers)
        self.validation_dataset_loader = DataLoader(self.validation_dataset, batch_size=settings.batch_size,
                                                    pin_memory=self.settings.pin_memory,
                                                    num_workers=settings.number_of_data_workers)
        
        self.test_dataset_loader = DataLoader(self.test_dataset, batch_size=None,
                                                pin_memory=self.settings.pin_memory,
                                                num_workers=settings.number_of_data_workers)
        

    def model_setup(self):
        """Prepares all the model architectures required for the application."""
        self.DNN = R_DNN()

    def labeled_loss_function(self, predicted_labels, labels, order=2):
        """Computes the labelled loss, even though it is single goal it should handle missing labels."""
        
        # Find the indexes of non negative labels
        grad_indexes = np.where(labels >= 0)[0]
        
        return (predicted_labels[grad_indexes] - labels[grad_indexes]).abs().pow(order).mean()




    def evaluation_epoch(self, settings, network, dataset, summary_writer, summary_name, shuffle=True):

        dataset_loader = DataLoader(dataset, batch_size=settings.batch_size, shuffle=shuffle,
                                    pin_memory=self.settings.pin_memory,
                                    num_workers=settings.number_of_data_workers)
        predicted_ic50, true_ic50 = np.array([]), np.array([])

        for index, (label, ic50) in enumerate(dataset_loader):
            ic50 = ic50.abs()
            label, ic50 = label.to(gpu), ic50.to(gpu)

            predicted_ic50 = np.append(predicted_ic50, network(label).detach().cpu().numpy())
            true_ic50 = np.append(true_ic50, ic50.detach().cpu().numpy())

            if index * self.settings.batch_size >= 100:
                break
            
        signed_mean_error = np.mean(predicted_ic50 - true_ic50)
        mean_error = np.mean(np.abs(predicted_ic50 - true_ic50))
        mean_squared_error = np.mean(np.square(predicted_ic50 - true_ic50))

        summary_writer.add_scalar(f"{summary_name}/Signed Mean Error", signed_mean_error)
        summary_writer.add_scalar(f"{summary_name}/Mean Error", mean_error)
        summary_writer.add_scalar(f"{summary_name}/Mean Squared Error", mean_squared_error)

        return mean_error
    

    def validation_summaries(self, step):
        Settings = self.settings
        dnn_summary_writer = self.dnn_summary_writer
        DNN = self.DNN
        train_dataset = self.train_dataset
        validation_dataset = self.validation_dataset
        print("validation summaries")

        self.evaluation_epoch(Settings, DNN, train_dataset, dnn_summary_writer, '2 Train Error', shuffle=False)
        self.evaluation_epoch(Settings, DNN, validation_dataset, dnn_summary_writer, '1 Validation Error',
                              shuffle=False)
        
        self.test_summaries()


    def test_summaries(self):
        test_dataset = self.test_dataset
        network = self.DNN  
        totals = defaultdict(lambda: 0)
        print("test summaries")
        for index, (label, ic50) in enumerate(test_dataset):
            # print(index)
            ic50 = ic50.abs()
            label, ic50 = label.to(gpu), ic50.to(gpu)
            predicted_ic50 = network(label)
            totals['Signed Mean Error'] += (predicted_ic50 - ic50).mean()
            totals['Mean Error'] += (predicted_ic50 - ic50).abs().mean()
            totals['Mean Squared Error'] += (predicted_ic50 - ic50).square().mean()
            if index >= 10:
                break

        summary_writer = self.dnn_summary_writer
        summary_writer.add_scalar(f"0 Test/Signed Mean Error", totals['Signed Mean Error']/10)
        summary_writer.add_scalar(f"0 Test/Mean Error", totals['Mean Error']/10)
        summary_writer.add_scalar(f"0 Test/Mean Squared Error", totals['Mean Squared Error']/10)
        
    def evaluate(self, during_training=False, step=None, number_of_examples=None):
        """Evaluates the model on test data."""
        self.model_setup()
        self.load_models()
        self.gpu_mode()
        self.eval_mode()
        self.dataset_setup()
        self.test_summaries()
        test_dataset = self.test_dataset
        network = self.DNN
        totals = defaultdict(lambda: 0)
        for index, (label, ic50) in enumerate(test_dataset):
            label, ic50 = label.to(gpu), ic50.to(gpu)
            predicted_ic50 = network(label)
            totals['Signed Mean Error'] += np.mean(predicted_ic50 - ic50)
            totals['Mean Error'] += np.mean(np.abs(predicted_ic50 - ic50))
            totals['Mean Squared Error'] += np.mean(np.square(predicted_ic50 - ic50))
        
        print(f"Signed Mean Error: {totals['Signed Mean Error']}")
        print(f"Mean Error: {totals['Mean Error']}")
        print(f"Mean Squared Error: {totals['Mean Squared Error']}")
        
        self.save_models(step)


    @property
    def inference_network(self):
        """The network to be used for inference."""
        return self.DNN



class DG_DNN_IC50(DNN_IC50):
    """Runs a Dual Goal DNN only version of the ic50 application."""
    
    def labeled_loss_function(self, predicted_labels, labels, order=2):
        """Computes the labelled loss, but because it is dual goal it must handle missing labels."""
        
        # Find the indexes of non-nan and non-negative labels
        grad_indexes = np.where((~np.isnan(labels)) & (labels >= 0))[0]
        
        return (predicted_labels[grad_indexes] - labels[grad_indexes]).abs().pow(order).mean()

    def model_setup(self):
        layersizes =[2**10, 2**10, 2**9, 2**7, 2**1]
        self.DNN = R_DNN(layersize=layersizes)

    def load_raw_data(self):
        settings = self.settings
        self.train_dataset = DG_Labelled_Dataset(csv_path=settings.train_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        
        self.validation_dataset = DG_Labelled_Dataset(csv_path=settings.validation_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        

        self.test_dataset = DG_Labelled_Dataset(csv_path=settings.test_dataset_path,
                                            seed=settings.labeled_dataset_seed)
        


