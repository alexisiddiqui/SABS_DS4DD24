"""The DNN only module."""
