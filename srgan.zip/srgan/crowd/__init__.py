"""The crowd application module."""
